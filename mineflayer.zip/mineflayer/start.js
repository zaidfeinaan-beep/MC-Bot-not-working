const mineflayer = require("mineflayer");
const http = require("http");

// 1. THIS RUNS THE WEB SERVER FOR REPLIT
const http = require("http");

// 1. DYNAMIC PORT BINDING FOR PRODUCTION
// Replit passes the correct port through process.env.PORT during deployment.
const PORT = process.env.PORT || 3000;

http
  .createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("Minecraft Bot is Awake!");
  })
  .listen(PORT, "0.0.0.0", () => {
    console.log(`✅ Web server loaded successfully on port ${PORT}!`);
  });

// 2. CHANGE THESE TO MATCH YOUR MINECRAFT SERVER
const bot = mineflayer.createBot({
  host: "og-svp-smp.aternos.me", // <-- Put your server IP here
  port: 46823, // <-- Put your server port here (default is 25555)
  username: "Broisawake", // <-- Give your bot a username
  version: false, // <-- Autodetects your server version
});

// 3. LOG WHEN THE BOT JOINS OR FAILS
bot.on("spawn", () => {
  console.log("🎮 Success! The bot has joined the Minecraft server.");
});

bot.on("error", (err) => {
  console.log("❌ Error connecting:", err.message);
});

bot.on("end", () => {
  console.log("🔌 The bot disconnected. Reconnecting...");
});
